﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace IconLib
{
    class ImageUtil
    {

        /// <summary>
        /// Gets the internal PixelFormat based on bits per pixel
        /// </summary>
        /// <param name="bpp">Bits per pixel.</param>
        /// <returns>PixelFormat corresponding to the input bpp.</returns>
        public static PixelFormat PixelFormatFromBpp(int bpp)
        {
            switch (bpp)
            {
                case 1:
                    return PixelFormat.Format1bppIndexed;
                case 4:
                    return PixelFormat.Format4bppIndexed;
                case 8:
                    return PixelFormat.Format8bppIndexed;
                case 24:
                    return PixelFormat.Format24bppRgb;
                case 32:
                    return PixelFormat.Format32bppArgb;
                default:
                    return PixelFormat.Undefined;
            }
        }


        /// <summary>
        /// Generates a Bitmap from an IconImage structure.
        /// </summary>
        /// <param name="iconImage">IconImage to convert to Bitmap.</param>
        /// <returns>Bitmap with exact size and depth as the provided IconImage</returns>
        internal unsafe static Bitmap BitmapFromIconImage(IconImage iconImage)
        {
            int width = iconImage.icHeader.biWidth;
            int height = width; // icons are square
            int bpp = iconImage.icHeader.biBitCount;
            PixelFormat pixelFormat = PixelFormatFromBpp(bpp);

            Bitmap bmp = new Bitmap(width, height, pixelFormat);

            // set the palette
            if ((pixelFormat & PixelFormat.Indexed) != 0)
            {

                ColorPalette palette = bmp.Palette;
                
                for (int i = 0; i < iconImage.icColors.Length; ++i)
                {
                    palette.Entries[i] = iconImage.icColors[i].GetColor();
                }
                bmp.Palette = palette;
            }

            // set the data
            BitmapData bmd = bmp.LockBits(new Rectangle(0, 0, width, height),
                ImageLockMode.WriteOnly,
                bmp.PixelFormat
                );

            {
                int datasize = bmd.Stride * bmd.Height;

                if (datasize != iconImage.icXOR.Length)
                {
                    Console.WriteLine("[error] Icon/bmp Data sizes do not match");
                    return null;
                }
                // flipped Y
                IntPtr p = bmd.Scan0;
                for (int y = height - 1; y >= 0; --y)
                {
                    IntPtr d = p + (y * bmd.Stride);
                    int s = (height - y - 1) * bmd.Stride;
                    Marshal.Copy(iconImage.icXOR, s, d, bmd.Stride);
                }
                bmp.UnlockBits(bmd);
            }

            return bmp;
        }

        internal static Image BlendImages(Image bottom, Image top)
        {
            using (Graphics graphics = Graphics.FromImage(bottom))
            {
                graphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;
                graphics.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.Default;
                graphics.DrawImage(top, new Rectangle(0, 0, bottom.Width, bottom.Height));
            }
            return bottom;
        }

        internal static Image ResizeImge(Image source, int width, int height)
        {
            Image resized;
            if (source.Width == width && source.Height == height)
            {
                // just make a copy
                resized = new Bitmap(source);
            }
            else
            {
                resized = new Bitmap(width, height, PixelFormat.Format32bppArgb);
                using (Graphics graphics = Graphics.FromImage(resized))
                {
                    graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                    graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                    graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                    graphics.DrawImage(source, new Rectangle(0, 0, width, height));
                }
            }
            return resized;
        }

        internal unsafe static Color[] GetImageData(Image image)
        {
            Bitmap bmp = image as Bitmap;
            BitmapData bmd = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, bmp.PixelFormat);

            int height = bmd.Height;
            int width = bmd.Width;
            int stride = bmd.Stride;
            int bpp = Bitmap.GetPixelFormatSize(bmp.PixelFormat);
            List<Color> colorData = new List<Color>();

            byte r, g, b, a;
            byte* p = (byte*)bmd.Scan0;
            for (int y = 0; y < bmd.Height; ++y)
            {
                byte* s = p + (y * stride); // current line
                for (int x = 0; x < width; ++x)
                {
                    b = *(s++);
                    g = *(s++);
                    r = *(s++);
                    a = bpp < 32 ? (byte)255 : *(s++);

                    colorData.Add(Color.FromArgb(a, r, g, b));

                }
                //p += bmd.Stride;
            }
            bmp.UnlockBits(bmd);

            return colorData.ToArray();
        }

    }
}
