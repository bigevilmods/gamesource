﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;

namespace IconLib
{
    class Helpers
    {
        static readonly Color Background = Color.DimGray;

        internal static Color ConvertAlpha(Color color, out int argbkey)
        {
            Color final = color;
            //TODO interpolate alpha

            argbkey = color.R << 24 | color.G << 8 | color.B;
            return final;
        }

        public static int FindNearestColor(Color color, IList<Color> palette)
        {
            
            int bestdistance = int.MaxValue;
            int bestindex = 0;
            int Rdiff;
            int Gdiff;
            int Bdiff;

            for (Int32 index = 0; index < palette.Count; ++index)
            {
                Color targetColor = palette[index];
                Rdiff = color.R - targetColor.R;
                Gdiff = color.G - targetColor.G;
                Bdiff = color.B - targetColor.B;
                int distance = Rdiff * Rdiff + Gdiff * Gdiff + Bdiff * Bdiff;
                                
                if (distance == 0)
                {
                    bestindex = index;
                    break;
                }
                                
                if (distance < bestdistance)
                {
                    bestdistance = distance;
                    bestindex = index;
                }
            }

            return bestindex;
        }
    }

    public class FastRandom
    {
        private const Double RealUnitInt = 1.0 / (Int32.MaxValue + 1.0);

        private UInt32 x, y, z, w;

        public FastRandom(UInt32 seed)
        {
            x = seed;
            y = 842502087;
            z = 3579807591;
            w = 273326509;
        }

        public Int32 Next(Int32 upperBound)
        {
            UInt32 t = (x ^ (x << 11)); x = y; y = z; z = w;
            return (Int32)((RealUnitInt * (Int32)(0x7FFFFFFF & (w = (w ^ (w >> 19)) ^ (t ^ (t >> 8))))) * upperBound);
        }
    }

}
