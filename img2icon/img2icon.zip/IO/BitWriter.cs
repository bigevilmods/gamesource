﻿using System.Diagnostics;

namespace System.IO
{
    public class BitWriter: BinaryWriter
    {
        uint mBitBuffer = 0;
        int mBitCount = 0;
        int mBytesWritten = 0;
        int mBitsWritten = 0;
        bool mLittleEndian;

        /// <summary>
        /// Gets or sets the endianness of the output
        /// </summary>
        public bool LittleEndian
        {
            get { return mLittleEndian; }
            set { mLittleEndian = value; }
        }

        public int BitsToAligment
        {
            get
            {
                return (32 - mBitCount) % 8;
            }
        }

        /// <summary>
        /// Returns the total number of bytes written to the stream.
        /// </summary>
        public int BytesWritten
        {
            get { return mBytesWritten; }
        }

        /// <summary>
        /// Returns the total number of valid bits written to the stream.
        /// </summary>
        public int BitsWritten
        {
            get { return mBitsWritten; }
        }

        /// <summary>
        /// Creates a new BitWriter.
        /// </summary>
        /// <param name="stream">The input stream.</param>
        /// <param name="littleEndian">True if the output is little-endian. False if big-endian.</param>
        public BitWriter(Stream stream, bool littleEndian)
            : base(stream)
        {
            this.mLittleEndian = littleEndian;
        }
        /// <summary>
        /// Writes a single bit to the buffer.
        /// </summary>
        /// <param name="value">True if the bit is 1. False if 0.</param>
        public void WriteBit(bool value)
        {
            WriteEndianBits(value ? 1 : 0, 1);
        }


        public void WriteBits(uint value, int length)
        {
            WriteEndianBits((int)value, length);
        }

        public void WriteBits(int value, int length)
        {
            WriteEndianBits(value, length);
        }

        /// <summary>
        /// Writes the given bits taking into account endianness. If the endianness of
        /// this computer is different from the endianness set for the file, the bytes will be
        /// swapped, otherwise they will not.
        /// </summary>
        void WriteEndianBits(int value, int length)
        {
            Debug.Assert(value < (1 << length), "value does not fit in length");

            if (mLittleEndian != BitConverter.IsLittleEndian)
            {
                int reversed = 0;
                for (int i = length - 1; i >= 0; i--)
                {
                    reversed <<= 1;
                    reversed |= value & 1;
                    value >>= 1;
                }
            }
#if false
            uint bitBuffer = mBitBuffer | checked((uint)value << mBitCount);
            int bitCount = mBitCount + length;
            while (bitCount >= 8)
            {
                base.Write((byte)bitBuffer);
                bitBuffer >>= 8;
                bitCount -= 8;
                mBytesWritten++;
                mBytesWritten += 8;
            }
            mBitBuffer = bitBuffer;
            mBitCount = bitCount;
#else
            uint bitBuffer = mBitBuffer;
            bitBuffer <<= length;
            bitBuffer |= (uint)value;

            int bitCount = mBitCount + length;

            while (bitCount >= 8)
            {
                base.Write((byte)(bitBuffer >> (bitCount-=8)));
                //bitBuffer >>= 8;
                
                mBytesWritten++;
                mBitsWritten += 8;
            }
            mBitBuffer = bitBuffer;
            mBitCount = bitCount;
#endif
        }

        /// <summary>
        /// Ensures that any bits left in the buffer are written to the stream.
        /// </summary>
        public void Align()
        {
            if (mBitCount > 0)
            {
#if false
                base.Write((byte)mBitBuffer);
#else
                
                base.Write((byte)((mBitBuffer << (8 - mBitCount)) & 0xff));
#endif
                mBytesWritten++;
                mBitsWritten += mBitCount;

                mBitBuffer = 0;
                mBitCount = 0;
                
            }
        }
    }
}
