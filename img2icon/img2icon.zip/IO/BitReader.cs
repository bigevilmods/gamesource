﻿using System;
using System.IO;

namespace System.IO
{
    public class BitReader : BinaryReader
    {
        private readonly int UINT_BITS = sizeof(UInt32) << 3;

        private int mBitBuffer;
        private int mBitsLeft;
        private bool mLittleEndian;

        /// <summary>
        /// Gets or sets the endianness of the input
        /// </summary>
        public bool LittleEndian
        {
            get { return mLittleEndian; }
            set { mLittleEndian = value; }
        }

        /// <summary>
        /// Gets the current bit buffer
        /// </summary>
        public int BitBuffer 
        { 
            get { return mBitBuffer; }
        }


        /// <summary>
        /// Creates a new BitReader.
        /// </summary>
        /// <param name="input">The input stream.</param>
        /// <param name="littleEndian">True if the input is little-endian. False if big-endian.</param>
        public BitReader(Stream input, bool littleEndian)
            : base(input)
        {
            mBitBuffer = 0;
            mBitsLeft = 0;
            mLittleEndian = littleEndian;
        }

        /// <summary>
        /// Ensures there are at least N bits in the bit buffer
        /// </summary>
        /// <param name="n">Number of bits to ensure.</param>
        public void EnsureBits(int n)
        {
            int bits;
            while (mBitsLeft < n)
            {
                if (BaseStream.Position == BaseStream.Length - 1)
                {
                    throw new IndexOutOfRangeException();
                }
                bits = (ReadByte() & 0xFF);
                mBitBuffer |= bits << (UINT_BITS - 8 - mBitsLeft);
                mBitsLeft += 8;
            }
        }

        /// <summary>
        /// Gets (without removing) N bits from the bit buffer.
        /// </summary>
        /// <param name="n">Number of bits to peek.</param>
        /// <returns>Bits requested.</returns>
        public int PeekBits(int n)
        {
            return (int)((mBitBuffer >> (UINT_BITS - n)) & ~(~0 << n));
        }

        /// <summary>
        /// Removes N bits from the bit buffer
        /// </summary>
        /// <param name="n">Number of bits to remove.</param>
        public void RemoveBits(int n)
        {
            mBitBuffer <<= n;
            mBitsLeft -= n;
        }

        /// <summary>
        /// Takes N bits from the bit buffer
        /// </summary>
        /// <param name="n">Number of bits to get</param>
        /// <returns>bits requested.</returns>
        public int ReadBits(int n)
        {
            EnsureBits(n);
            int result = PeekBits(n);
            RemoveBits(n);
            return result;
        }
        /// <summary>
        /// Skip n amount of bytes.
        /// </summary>
        /// <param name="n"></param>
        public void Skip(int n)
        {
            ReadBytes(n);
        }

        /// <summary>
        /// Overridden from <see cref="BinaryReader"/>.
        /// </summary>
        /// <returns>The value read from the stream.</returns>
        public override ushort ReadUInt16()
        {
            return BitConverter.ToUInt16(ReadEndianBytes(2), 0);
        }

        /// <summary>
        /// Overridden from <see cref="BinaryReader"/>.
        /// </summary>
        /// <returns>The value read from the stream.</returns>
        public override uint ReadUInt32()
        {
            return BitConverter.ToUInt32(ReadEndianBytes(4), 0);
        }

        private byte[] ReadEndianBytes(int count)
        {
            byte[] bytes = new byte[count];
            Read(bytes, 0, count);

            if (mLittleEndian != BitConverter.IsLittleEndian)
            {
                Array.Reverse(bytes);
            }
            return bytes;
        }
    }
}
