﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Collections.Concurrent;
using System.Drawing;


namespace IconLib.Quantizers
{
    public abstract class BaseQuantizer : IQuantizer
    {
        /// <summary>
        /// This index will represent invalid palette index.
        /// </summary>
        protected const int InvalidIndex = -1;


        private Boolean paletteFound;
        private Int64 uniqueColorIndex;
        protected readonly ConcurrentDictionary<int, Int16> UniqueColors;

        protected BaseQuantizer()
        {
            //pathProvider = null;
            uniqueColorIndex = -1;
            UniqueColors = new ConcurrentDictionary<int, Int16>();
        }


        /// <summary>
        /// Called when quantizer is about to be prepared for next round.
        /// </summary>
        protected virtual void OnPrepare(Image image)
        {
            uniqueColorIndex = -1;
            paletteFound = false;
            UniqueColors.Clear();
        }

        /// <summary>
        /// Called when color is to be added.
        /// </summary>
        protected virtual void OnAddColor(Color color, int key, int x, int y)
        {
            UniqueColors.AddOrUpdate(key,
                colorKey => (Byte)Interlocked.Increment(ref uniqueColorIndex),
                (colorKey, colorIndex) => colorIndex);
        }

        /// <summary>
        /// Called when quantized palette is needed.
        /// </summary>
        protected virtual List<Color> OnGetPalette(int colorCount)
        {
            // early optimalization, in case the color count is lower than total unique color count
            if (UniqueColors.Count > 0 && colorCount >= UniqueColors.Count)
            {
                // palette was found
                paletteFound = true;

                // generates the palette from unique numbers
                return UniqueColors.
                    OrderBy(pair => pair.Value).
                    Select(pair => Color.FromArgb(pair.Key)).
                    Select(color => Color.FromArgb(255, color.R, color.G, color.B)).
                    ToList();
            }

            // otherwise make it descendant responsibility
            return null;
        }

        /// <summary>
        /// Called when get palette index for a given color should be returned.
        /// </summary>
        protected virtual void OnGetPaletteIndex(Color color, int key, int x, int y, out int paletteIndex)
        {
            // by default unknown index is returned
            paletteIndex = InvalidIndex;
            Int16 foundIndex;

            // if we previously found palette quickly (without quantization), use it
            if (paletteFound && UniqueColors.TryGetValue(key, out foundIndex))
            {
                paletteIndex = foundIndex;
            }
        }

        /// <summary>
        /// Called when about to clear left-overs after quantization.
        /// </summary>
        protected virtual void OnFinish()
        {
            // do nothing here
        }

        #region IQuantizer Members

        /// <summary>
        /// See <see cref="IQuantizer.Prepare"/> for more details.
        /// </summary>
        public void Prepare(Image image)
        {
            OnPrepare(image);
        }

        /// <summary>
        /// See <see cref="IQuantizer.AddColor"/> for more details.
        /// </summary>
        public void AddColor(Color color, int x, int y)
        {
            int key;
            color = Helpers.ConvertAlpha(color, out key);
            OnAddColor(color, key, x, y);
        }
        /// <summary>
        /// See <see cref="IQuantizer.GetPalette"/> for more details.
        /// </summary>
        public List<Color> GetPalette(int colorCount)
        {
            return OnGetPalette(colorCount);
        }

        /// <summary>
        /// See <see cref="IQuantizer.GetPaletteIndex"/> for more details.
        /// </summary>
        public int GetPaletteIndex(Color color, int x, int y)
        {
            int result, key;
            color = Helpers.ConvertAlpha(color, out key);
            OnGetPaletteIndex(color, key, x, y, out result);
            return result;
        }

        /// <summary>
        /// See <see cref="IQuantizer.Finish"/> for more details.
        /// </summary>
        public void Finish()
        {
            OnFinish();
        }

        #endregion
    }
}
