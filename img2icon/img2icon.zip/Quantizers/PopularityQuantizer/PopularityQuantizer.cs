﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace IconLib.Quantizers
{
    class PopularityQuantizer : BaseQuantizer
    {
        private List<Color> palette;
        private ConcurrentDictionary<int, PopularityColorSlot> colorMap;

        private static int GetColorIndex(Color color)
        {
            int redIndex = color.R >> 2;
            int greenIndex = color.G >> 2;
            int blueIndex = color.B >> 2;

            return (redIndex << 12) + (greenIndex << 6) + blueIndex;
        }

        /// <summary>
        /// See <see cref="BaseColorQuantizer.OnPrepare"/> for more details.
        /// </summary>
        protected override void OnPrepare(Image image)
        {
            base.OnPrepare(image);

            palette = new List<Color>();
            colorMap = new ConcurrentDictionary<int, PopularityColorSlot>();
        }
                

        protected override void OnAddColor(Color color, int key, int x, int y)
        {
            base.OnAddColor(color, key, x, y);
            int index = GetColorIndex(color);
            colorMap.AddOrUpdate(index, colorKey => new PopularityColorSlot(color), (colorKey, slot) => slot.AddValue(color));
        }

        /// <summary>
        /// See <see cref="BaseColorCacheQuantizer.OnGetPaletteToCache"/> for more details.
        /// </summary>
        protected override List<Color> OnGetPalette(int colorCount)
        {
            // use fast random class
            FastRandom random = new FastRandom(0);

            // NOTE: I've added a little randomization here, as it was performing terribly otherwise.
            // sorts out the list by a pixel presence, takes top N slots, and calculates 
            // the average color from them, thus our new palette.
            IEnumerable<Color> colors = colorMap.
                 OrderBy(entry => random.Next(colorMap.Count)).
                 OrderByDescending(entry => entry.Value.PixelCount).
                 Take(colorCount).
                 Select(entry => entry.Value.GetAverage());

            palette.Clear();
            palette.AddRange(colors);
            return palette;
        }
    }


    internal class PopularityColorSlot
    {
        #region | Fields |

        private int red;
        private int green;
        private int blue;

        #endregion

        #region | Properties |

        /// <summary>
        /// Gets or sets the pixel count.
        /// </summary>
        /// <value>The pixel count.</value>
        public int PixelCount { get; private set; }

        #endregion

        #region | Constructors |

        /// <summary>
        /// Initializes a new instance of the <see cref="PopularityColorSlot"/> class.
        /// </summary>
        /// <param name="color">The color.</param>
        public PopularityColorSlot(Color color)
        {
            AddValue(color);
        }

        #endregion

        #region | Methods |

        /// <summary>
        /// Adds the value to the slot.
        /// </summary>
        /// <param name="color">The color to be added.</param>
        public PopularityColorSlot AddValue(Color color)
        {
            red += color.R;
            green += color.G;
            blue += color.B;
            PixelCount++;
            return this;
        }

        /// <summary>
        /// Gets the average, just simple value divided by pixel presence.
        /// </summary>
        /// <returns>The average color component value.</returns>
        public Color GetAverage()
        {
            // determines the components
            int finalRed = red / PixelCount;
            int finalGreen = green / PixelCount;
            int finalBlue = blue / PixelCount;

            // clamps the invalid values
            if (finalRed < 0) finalRed = 0;
            if (finalRed > 255) finalRed = 255;
            if (finalGreen < 0) finalGreen = 0;
            if (finalGreen > 255) finalGreen = 255;
            if (finalBlue < 0) finalBlue = 0;
            if (finalBlue > 255) finalBlue = 255;

            // returns the reconstructed color
            return Color.FromArgb(255, finalRed, finalGreen, finalBlue);
        }

        #endregion
    }
}
