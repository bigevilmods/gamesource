﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace IconLib.Quantizers
{
    interface IQuantizer
    {

        /// <summary>
        /// Prepares the quantizer for image processing.
        /// </summary>
        void Prepare(Image image);

        // <summary>
        /// Adds the color to quantizer.
        /// </summary>
        void AddColor(Color color, Int32 x, Int32 y);

        /// <summary>
        /// Gets the index of the palette for specific color.
        /// </summary>
        Int32 GetPaletteIndex(Color color, Int32 x, Int32 y);

        /// <summary>
        /// Gets the palette with specified count of the colors.
        /// </summary>
        List<Color> GetPalette(Int32 colorCount);

        /// <summary>
        /// Clears this instance.
        /// </summary>
        void Finish();
    }
}
