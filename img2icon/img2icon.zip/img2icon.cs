﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using IconLib.Quantizers;

namespace IconLib
{

    enum BitmapCompression
    {
        BI_RGB,
        BI_RLE8,
        BI_RLE4,
        BI_BITFIELDS,
        BI_JPEG,
        BI_PNG
    }

    class img2icon
    {

        static int DumpIcon(string filename, string outputpath="")
        {
            int retcode = 0;
            IconDecoder decoder = new IconDecoder();
            List<IconImage> imageList = decoder.Read(filename);

            string basename = Path.Combine(outputpath,Path.GetFileNameWithoutExtension(filename));
            
            foreach (var entry in imageList)
            {

                BitmapInfoHeader header = entry.icHeader;
                int width = header.biWidth;
                int height = width;
                IconImageType iconType = header.biCompression == BitmapInfoHeader.BI_PNG ? IconImageType.PNG : IconImageType.BMP;

                string output = String.Format("{0}_{1}x{2}x{3}", basename, header.biWidth, entry.icHeader.biWidth, header.biBitCount);
                
                if (iconType == IconImageType.BMP)
                {
                    output += ".bmp";
                    Bitmap bmp = ImageUtil.BitmapFromIconImage(entry);

                    if (bmp != null)
                        bmp.Save(output, ImageFormat.Bmp);
                }

                else if (iconType == IconImageType.PNG)
                {
                    output += ".png";
                    using (FileStream fs = File.Create(output))
                    {
                        fs.Write(entry.icXOR, 0, entry.icXOR.Length);
                    }
                }
                else
                {
                    Console.WriteLine("[error] Unknown icon type {0}x{1}x{2}", width, height, header.biBitCount);
                    retcode++;
                    continue;
                }

                Console.WriteLine(output);

            }

            return retcode;
        }


        static void CreateIcon(string source, string output)
        {
            int[] iconSizes = new int[] { 256, 48, 32, 16 };
            int[] iconDepths = new int[] { 1, 4, 8, 32 };
            
            Image image = Image.FromFile(source);
            if( Image.GetPixelFormatSize(image.PixelFormat) < 24)
            {
                Console.WriteLine("[error] sourc image should be 24 or 32 bpp");
                return;
            }


            IQuantizer quantizer = new WuColorQuantizer();

            IconEncoder encoder = new IconEncoder(quantizer);
            
            foreach(var depth in iconDepths)
                foreach (var size in iconSizes)
                {
                    encoder.AddImage(image, size, depth);
                }
            encoder.Save(output);

        }


        static void Main(string[] args)
        {
            string filename = @"test.ico";
            filename = @"E:\work\projects\Icon\images\fifapc.ico";
            DumpIcon(filename);

            filename = @"E:\work\projects\Icon\images\test256x256.png";
            string output = Path.Combine(Path.GetDirectoryName(filename), Path.GetFileNameWithoutExtension(filename) + ".ico");

            DumpIcon(output);

            CreateIcon(filename, output);

        }
    }
}
