﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace IconLib
{
    [StructLayout(LayoutKind.Sequential)]
    struct IconImage
    {
        public BitmapInfoHeader icHeader;  // DIB header
        public RGBQuad[] icColors;   // Color Table
        public byte[] icXOR; // DIB bits for XOR mask
        public byte[] icAND; // DIB bits for AND mask
        
    }
}
