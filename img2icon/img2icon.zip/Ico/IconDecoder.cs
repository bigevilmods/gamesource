﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;

namespace IconLib
{
    class IconDecoder
    {

        IconImageType PeekFormat(Stream stream)
        {
            IconImageType iconType = IconImageType.BMP;
            int position = (int)stream.Position;
            byte[] signature = new byte[4];

            stream.Read(signature, 0, 4);

            if (signature[0] == 137 && signature[1] == 80 && signature[2] == 78 && signature[3] == 71)
            {
                iconType = IconImageType.PNG;
            }
            else if ((signature[0] == 0x42) && (signature[1] == 0x4D))
            {
                //In BITMAPFILEHEADER, the first two bytes represents, in ASCII code, BM
                iconType = IconImageType.BMP;
                position += 14;
            }
            else if (signature[0] == 40)
            {
                // first entry in BitmapInfoHeader biSize  should always be 40.
                iconType = IconImageType.BMP;
            }
            else
            {
                iconType = IconImageType.UNKNOWN;
            }
            stream.Seek(position, SeekOrigin.Begin);

            return iconType;
        }

        IconImage ReadImage(Stream stream, IconDirEntry entry)
        {
            int position = (int)stream.Position;
            IconImage iconImage = new IconImage();

            BitmapInfoHeader icHeader = new BitmapInfoHeader();
            icHeader.Read(stream);

            uint colorMapSize = 0;
            if (icHeader.biClrUsed != 0)
                colorMapSize = icHeader.biClrUsed;
            else if (icHeader.biBitCount <= 8)
                colorMapSize = 1u << icHeader.biBitCount;
            else
                colorMapSize = 0;

            // read the color palette
            RGBQuad[] icColors = new RGBQuad[colorMapSize];

            for (int i = 0; i < colorMapSize; ++i)
            {
                RGBQuad rgbquad = new RGBQuad();
                rgbquad.Read(stream);
                icColors[i] = rgbquad;
            }

            iconImage.icHeader = icHeader;
            iconImage.icColors = icColors;

            int width = entry.bWidth == 0 ? 256 : entry.bWidth;
            int height = entry.bHeight == 0 ? 256 : entry.bHeight;

            bool hasAndMask = (width * 2 == icHeader.biHeight);

            // read the DIB bits for the XOR mask.
            int xorstride = (((icHeader.biWidth * icHeader.biBitCount) + 31) / 32) * 4;
            byte[] XORData = new byte[xorstride * height];
            stream.Read(XORData, 0, XORData.Length);
            iconImage.icXOR = XORData;

            // read the AND mask.
            if (hasAndMask)
            {
                int andstride = (((icHeader.biWidth) + 31) / 32) * 4;
                byte[] ANDData = new byte[andstride * height];
                stream.Read(ANDData, 0, ANDData.Length);
                iconImage.icAND = ANDData;
            }


            if (stream.Position != (entry.dwImageOffset + entry.dwBytesInRes))
            {
                Console.WriteLine("[error] read past the data size");
            }
            return iconImage;


        }
        
        public List<IconImage> Read(Stream stream)
        {
            List<IconImage> imageList = new List<IconImage>();

            IconDir icDir = IconDir.FromStream(stream);

            foreach (var entry in icDir.idEntries)
            {
                if (stream.Position != entry.dwImageOffset)
                {
                    stream.Seek(entry.dwImageOffset, SeekOrigin.Begin);
                }

                IconImageType iconType = PeekFormat(stream);

                if (iconType == IconImageType.BMP)
                {
                    IconImage iconImage = ReadImage(stream, entry);
                    imageList.Add(iconImage);
                }
                else if (iconType == IconImageType.PNG)
                {
                    int width = entry.bWidth == 0 ? 256: entry.bWidth;
                    int height = entry.bHeight == 0 ? 256 : entry.bHeight;

                    IconImage iconImage = new IconImage();
                    BitmapInfoHeader header = new BitmapInfoHeader();

                    header.biWidth = width;
                    header.biHeight = height;
                    header.biBitCount = 32;
                    header.biCompression = (int)BitmapCompression.BI_PNG;
                    
                    byte[] pngdata  = new byte[entry.dwBytesInRes];
                    stream.Read(pngdata, 0, (int)entry.dwBytesInRes);

                    iconImage.icHeader = header;
                    iconImage.icColors = null;
                    iconImage.icXOR = pngdata;
                    iconImage.icAND = null;

                    imageList.Add(iconImage);
                }
                else
                {
                    Console.WriteLine("[error] Unknown icon type {0}x{1}x{2}", entry.bWidth, entry.bHeight, entry.wBitCount);
                    continue;
                }
            }

            return imageList;
        }


        public List<IconImage> Read(string filename)
        {
            using (Stream stream = File.OpenRead(filename))
            {
                return Read(stream);
            }
        }
    }
} 

