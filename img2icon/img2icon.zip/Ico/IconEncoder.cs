﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using IconLib.Quantizers;
using System.IO;

namespace IconLib
{
    class IconEncoder
    {
        List<IconImage> mIconList;
        IQuantizer mQuantizer;
        Dictionary<string, Image> mImageCache;
        Color mMaskColor;
        

        public IQuantizer Quantizer
        {
            get { return mQuantizer; }
            set { mQuantizer = value; }
        }

        public Color MaskColor {
            get { return mMaskColor; }
            set { mMaskColor = value; }
        }

        public IconEncoder(IQuantizer quantizer)
        {
            mQuantizer = quantizer;
            mIconList = new List<IconImage>();
            mImageCache = new Dictionary<string, Image>();
            mMaskColor = Color.FromArgb(255, 128, 128, 0);
        }

        public IconEncoder() : this(new OctreeQuantizer()) { }
        
        void setBit(ref byte bits, int index, int bit)
        {
            if (bit == 0)
            {
                bits &= (byte)(~(1 << (7 - index)));
            }
            else
            {
                bits |= (byte)(1 << (7 - index));
            }
        }

        byte[] CreateMask(Color[] colormap, int width, int height, bool useColorMask=false)
        {
            int stride = ((width + 31) / 32) * 4;
            byte[] mask = new byte[stride*width];

            for (int y = 0; y < height; ++y)
            {
                int row = (height - y - 1) * stride;//stride * y;
                for (int x = 0; x < width; ++x)
                {
                    int bi = (x >> 3) + row;
                    int i = x % 8;
                    Color color = colormap[y * width + x];

                    int v;
                    if (useColorMask)
                        v = (color == mMaskColor) ? 0 : 1;
                    else
                        v = color.A > 127 ? 0 : 1;


                    setBit(ref mask[bi], i, v);
                }
            }
            return mask;
        }


        byte[] PackIndices(byte[] indices, int width, int height, int bpp)
        {
            int stride = (((width * bpp) + 31) / 32) * 4;
            byte[] packed = new byte[stride * height];

            switch (bpp)
            {
                case 1:
                    for (int y = 0; y < height; ++y)
                    {
                        int row = (height - y - 1) * stride; // upside down
                        for (int x = 0; x < width; ++x)
                        {
                            int bi = (x >> 3) + row;
                            int i = x % 8;
                            int v = indices[y * width + x];
                            setBit(ref packed[bi], i, v); }
                    }
                    break;
                case 4:
                    for (int y = 0; y < height; ++y)
                    {
                        int row = (height - y - 1) * stride; // upside down
                        for (int x = 0; x < width; ++x)
                        {
                            int bi = (x >> 1) + row;
                            int i = x % 2;
                            int v = indices[y * width + x];
                            packed[bi] |= (byte)(v << ((1 - i) * 4));
                        }
                    }
                    break;
                case 8:
                    for (int y = 0; y < height; ++y)
                    {
                        int row = (height - y - 1) * width;
                        for (int x = 0; x < width; ++x)
                        {
                            int s = row + x;
                            packed[y * width + x]= indices[s];
                        }
                    }
                    break;
            }
            return packed;

        }

        private byte Limits(int a, int b)
        {
            return (a + b) < 0 ? (byte)0 : (a + b) > 255 ? (byte)255 : (byte)(a + b);
        }
        // Floyd Steinberg Dithering
        void Disperse(int x, int y, ref Color[] colorData, int width, int height, Color targetColor)
        {
            byte r, g, b;

            Color sourceColor = colorData[y * width + x];
            int errorB = sourceColor.B - targetColor.B;
            int errorG = sourceColor.G - targetColor.G;
            int errorR = sourceColor.R - targetColor.R;

            Color sample;
            int sampleIdx;
            if (x + 1 < width)
            {
                sampleIdx = (y * width) + (x + 1);
                sample = colorData[sampleIdx];
                r = Limits(sample.R, (errorR * 7) >> 4);
                g = Limits(sample.G, (errorG * 7) >> 4);
                b = Limits(sample.B, (errorB * 7) >> 4);
                colorData[sampleIdx] = Color.FromArgb(sample.A, r, g, b);
            }
            if (y + 1 < height)
            {
                if (x - 1 > 0)
                {
                    // Left and Down
                    sampleIdx = ((y + 1) * width) + (x - 1);
                    sample = colorData[sampleIdx];
                    r = Limits(sample.R, (errorR * 3) >> 4);
                    g = Limits(sample.G, (errorG * 3) >> 4);
                    b = Limits(sample.B, (errorB * 3) >> 4);
                    colorData[sampleIdx] = Color.FromArgb(sample.A, r, g, b);
                }

                // Down
                sampleIdx = ((y + 1) * width) + (x + 0);
                sample = colorData[sampleIdx];
                r = Limits(sample.R, (errorR * 5) >> 4);
                g = Limits(sample.G, (errorG * 5) >> 4);
                b = Limits(sample.B, (errorB * 5) >> 4);
                colorData[sampleIdx] = Color.FromArgb(sample.A, r, g, b);

                if (x + 1 < width)
                {
                    // Right and Down
                    sampleIdx = ((y + 1) * width) + (x + 1);
                    sample = colorData[sampleIdx];
                    r = Limits(sample.R, (errorR * 1) >> 4);
                    g = Limits(sample.G, (errorG * 1) >> 4);
                    b = Limits(sample.B, (errorB * 1) >> 4);
                    colorData[sampleIdx] = Color.FromArgb(sample.A, r, g, b);
                }
            }
        }

        public void AddImage(Image source, int size, int bpp)
        {
            if (source.Width < size || source.Height < size)
            {
                Console.WriteLine("[warning] Image source smaller that destination icon frame {0}x{0} {1} bpp. Ignoring this frame.", size, bpp);
                return;
            }

            string cacheKey = String.Format("_{0}_{1}_", size,size);
            int width = size, height = size;
            Image resized;

            // See if we already have the resized image.
            // Otherwise resize image
            if (!mImageCache.TryGetValue(cacheKey, out resized))
            {
                resized = ImageUtil.ResizeImge(source, width, height);
                mImageCache.Add(cacheKey, resized);
            }
            
            Color[] colorData = ImageUtil.GetImageData(resized);
            List<Color> palette = new List<Color>();
            byte[] XOR = null, AND = null;
            bool isPNG = false;

            if (bpp <= 8)
            {
                mQuantizer.Prepare(resized);

                // quantize image
                for (int i = 0; i < colorData.Length; ++i)
                {
                    int x = i % width;
                    int y = i / width;

                    mQuantizer.AddColor(colorData[i], x, y);
                }

                // get palette
                palette = mQuantizer.GetPalette(1 << bpp);

                // remap color indices
                byte[] indices = new byte[colorData.Length];
                for (int i = 0; i < colorData.Length; ++i)
                {
                    int x = i % width;
                    int y = i / width;

                    int idx = mQuantizer.GetPaletteIndex(colorData[i], x, y);
                    if (idx < 0)
                    {
                        idx = Helpers.FindNearestColor(colorData[i], palette);
                    }
                    indices[i] = (byte)idx;

                    // optional dither
                    // mDither.Disperse(x,y, ref ColorData, width, height, palette[idx]);
                    //Disperse(x, y, ref colorData, width, height, palette[idx]);
                }


                // Reset the quantizer.
                mQuantizer.Finish();
                
                // pack the indices into the XOR array
                XOR = PackIndices(indices, width, height, bpp);

                // get the AND mask
                AND = CreateMask(colorData, width, height);

            }
            else
            {
                if (size == 256 && bpp >= 24) 
                {
                    // XOR is just a PNG. No AND Mask needed.
                    using (MemoryStream ms = new MemoryStream())
                    {
                        resized.Save(ms, ImageFormat.Png);
                        XOR = ms.ToArray();
                    }
                    // AND Mask not needed. Just initialize it to 0.
                    AND = new byte[0];
                    isPNG = true;
                }
                else
                {
                    // Create the raw XOR byte array from the colorData
                    int stride = (((width * bpp) + 31) / 32) * 4;
                    XOR = new byte[stride * height];
                    int d = 0;
                    for (int y = height - 1; y >= 0; --y)
                    {
                        int row = width * y;
                        for (int x = 0; x < width; ++x)
                        {
                            Color c = colorData[row + x];
                            XOR[d++] = c.B;
                            XOR[d++] = c.G;
                            XOR[d++] = c.R;
                            if(bpp > 24) XOR[d++] = c.A;
                        }
                    }

                    // Create the AND Mask
                    AND = CreateMask(colorData, width, height);
                }
                
            }

            // populate the RGBQuad palette.
            RGBQuad[] icColors = new RGBQuad[palette.Count];
            for (int i = 0; i < palette.Count; ++i)
            {
                icColors[i] = RGBQuad.FromColor(palette[i]);
            }


            // Populate the header for this image
            BitmapInfoHeader icHeader = new BitmapInfoHeader();
            uint colorsUsed = (uint)( (bpp <= 8) && (1 << bpp)  > icColors.Length  ? icColors.Length: 0);
            icHeader.biSize = 40;
            icHeader.biWidth = width;
            icHeader.biHeight = AND == null ? height : height*2;
            icHeader.biPlanes = 1;
            icHeader.biBitCount = (ushort)bpp;
            icHeader.biCompression = (uint)(isPNG ? BitmapInfoHeader.BI_PNG : 0);
            icHeader.biSizeImage = 0;
            icHeader.biXPelsPerMeter = 0;
            icHeader.biYPelsPerMeter = 0;
            icHeader.biClrUsed = colorsUsed;
            icHeader.biClrImportant = 0;
            
            IconImage iconImage = new IconImage();
            iconImage.icHeader = icHeader;
            iconImage.icColors = icColors;
            iconImage.icXOR = XOR;
            iconImage.icAND = AND;

            mIconList.Add(iconImage);
        }

        public void Save(Stream stream)
        {
            // order the list by depth ascending and size descending
            List<IconImage> iconImages = mIconList.
                 OrderBy(entry => entry.icHeader.biBitCount).
                 ThenByDescending(entry => entry.icHeader.biWidth).ToList();

            // populate the iconDirEntries
            List<IconDirEntry> iconDirEntries = new List<IconDirEntry>();
            foreach (var iconImage in iconImages)
            {
                IconDirEntry de = new IconDirEntry();
                byte size = (byte)(iconImage.icHeader.biWidth == 256 ? 0 : iconImage.icHeader.biWidth);
                byte colorcount = (byte)(iconImage.icHeader.biBitCount >= 8 ? 0 : (1 << iconImage.icHeader.biBitCount));
                uint resourceSize = (uint)(40 + (iconImage.icColors.Length*4) + iconImage.icXOR.Length + iconImage.icAND.Length);

                de.bWidth = size;
                de.bHeight = size; // assuming square
                de.bColorCount = colorcount;
                de.bReserved = 0;
                de.wPlanes = 1;
                de.wBitCount = iconImage.icHeader.biBitCount;
                de.dwBytesInRes = resourceSize;
                de.dwImageOffset = 0;

                iconDirEntries.Add(de);
            }

            // create the file header
            IconDir iconDir = new IconDir();
            iconDir.idReserved = 0;
            iconDir.idType = 1; 
            iconDir.idCount = (ushort)iconImages.Count;
            iconDir.idEntries = null;// iconDirEntries.ToArray(); // don't set, well write ourselves.

            // Write out the header
            iconDir.Write(stream);

            // Write out the iconDirEntries
            long iconDirentryOffset = stream.Position; // remember where we are.
            foreach (var de in iconDirEntries)
                de.Write(stream);

            // Write out the bitmap  data and update the respective iconDirEntry with the file offset;
            for (int i = 0; i < iconImages.Count; ++i)
            {
                IconDirEntry de = iconDirEntries[i];
                de.dwImageOffset = (uint)stream.Position;

                IconImage iconImage = iconImages[i];

                bool isPNG = iconImage.icHeader.biCompression == BitmapInfoHeader.BI_PNG;
                if (!isPNG)
                {
                    // BitmapInfoHeader
                    iconImage.icHeader.Write(stream);

                    // Palette
                    foreach (var rgb in iconImage.icColors)
                        rgb.Write(stream);

                    // Color XOR
                    stream.Write(iconImage.icXOR, 0, iconImage.icXOR.Length);

                    // AND Mask
                    stream.Write(iconImage.icAND, 0, iconImage.icAND.Length);
                }
                else
                {
                    // Color XOR which contains the raw PNG
                    stream.Write(iconImage.icXOR, 0, iconImage.icXOR.Length);
                }

                long curpos = stream.Position;
                if (curpos - de.dwImageOffset != de.dwBytesInRes)
                    de.dwBytesInRes = (uint)(curpos - de.dwImageOffset);

                iconDirEntries[i] = de;

            }

            // go back and write the updated IconDirectoryEntries
            stream.Seek(iconDirentryOffset, SeekOrigin.Begin);

            foreach (var de in iconDirEntries)
                de.Write(stream);

            // set the stream positon back to the end.
            stream.Seek(0, SeekOrigin.End);


        }

        public void Save(string filename)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                Save(ms);
                using (FileStream fs = File.Create(filename))
                {
                    ms.Flush();
                    ms.WriteTo(fs);
                }
            }
        }
    }
}
