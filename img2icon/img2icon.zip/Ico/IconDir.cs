﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace IconLib
{
    [StructLayout(LayoutKind.Sequential)]
    struct IconDir
    {
        public ushort idReserved;   // Reserved (must be 0)
        public ushort idType;       // Resource Type (1 for icons)
        public ushort idCount;      // Number of images in icon file,
        public IconDirEntry[] idEntries;   // An entry for each image (idCount of 'em)

        public void Read(Stream stream)
        {
            BinaryReader reader = new BinaryReader(stream);
            
            idReserved = reader.ReadUInt16();
            idType = reader.ReadUInt16();
            idCount = reader.ReadUInt16();

            idEntries = new IconDirEntry[idCount];
            for (int i = 0; i < idCount; ++i)
            {
                idEntries[i] = IconDirEntry.FromStream(stream);
            }

        }

        public void Write(Stream stream)
        {
            BinaryWriter writer = new BinaryWriter(stream);
            
            writer.Write(idReserved);
            writer.Write(idType);
            writer.Write(idCount);
            
            if(idEntries != null)
                for (int i = 0; i < idCount; ++i)
                {
                    idEntries[i].Write(stream);
                }

        }

        public static IconDir FromStream(Stream stream)
        {
            IconDir id = new IconDir();
            id.Read(stream);
            return id;
        }
    }
}
