﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
namespace IconLib
{
    [StructLayout(LayoutKind.Sequential)]
    public struct RGBQuad
    {
        public byte rgbBlue;
        public byte rgbGreen;
        public byte rgbRed;
        public byte rgbReserved;

        public void Write(Stream writer)
        {
            writer.WriteByte(rgbBlue);
            writer.WriteByte(rgbGreen);
            writer.WriteByte(rgbRed);
            writer.WriteByte(rgbReserved);
        }

        public void Read(Stream reader)
        {
            rgbBlue = (byte)reader.ReadByte();
            rgbGreen = (byte)reader.ReadByte();
            rgbRed = (byte)reader.ReadByte();
            rgbReserved = (byte)reader.ReadByte();
        }

        public Color GetColor()
        {
            return System.Drawing.Color.FromArgb(rgbReserved, rgbRed, rgbGreen, rgbBlue);
        }

        public static RGBQuad FromRGB(byte r, byte g, byte b)
        {
            RGBQuad output = new RGBQuad();
            output.rgbRed = r;
            output.rgbGreen = g;
            output.rgbBlue = b;
            output.rgbReserved = 255;
            return output;
        }
        public static RGBQuad FromRGBA(byte r, byte g, byte b, byte a)
        {
            RGBQuad output = FromRGB(r, g, b);
            output.rgbReserved = a;
            return output;
        }

        public static RGBQuad FromColor(Color color)
        {
            RGBQuad output = FromRGBA(color.R,color.G,color.B, color.A);
            return output;
        }
    }
}
