﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace IconLib
{
    [StructLayout(LayoutKind.Sequential)]
    struct IconDirEntry
    {
        public byte bWidth;          // Width, in pixels, of the image
        public byte bHeight;         // Height, in pixels, of the image
        public byte bColorCount;     // Number of colors in image (0 if >=8bpp)
        public byte bReserved;       // Reserved ( must be 0)
        public ushort wPlanes;       // Color Planes
        public ushort wBitCount;     // Bits per pixel
        public uint dwBytesInRes;    // How many bytes in this resource?
        public uint dwImageOffset;   // Where in the file is this image?

        public void Read(Stream stream)
        {
            BinaryReader reader = new BinaryReader(stream);
            bWidth = reader.ReadByte();       
            bHeight = reader.ReadByte();      
            bColorCount = reader.ReadByte();   
            bReserved = reader.ReadByte();     
            wPlanes = reader.ReadUInt16();     
            wBitCount = reader.ReadUInt16();   
            dwBytesInRes = reader.ReadUInt32();
            dwImageOffset= reader.ReadUInt32();
        }

        public void Write(Stream stream)
        {
            BinaryWriter writer = new BinaryWriter(stream);
            writer.Write(bWidth);
            writer.Write(bHeight);
            writer.Write(bColorCount);
            writer.Write(bReserved);
            writer.Write(wPlanes);
            writer.Write(wBitCount);
            writer.Write(dwBytesInRes);
            writer.Write(dwImageOffset);
        }

        public static IconDirEntry FromStream(Stream stream)
        {
            IconDirEntry ide = new IconDirEntry();
            ide.Read(stream);
            return ide;
        }
    }
}
